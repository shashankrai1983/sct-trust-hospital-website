'use client'

import { useSession } from 'next-auth/react'
import { usePathname } from 'next/navigation'
import Sidebar from './components/sidebar'
import Header from './components/header'

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { data: session } = useSession()
  const pathname = usePathname()

  // If no session, render children directly (for login page)
  if (!session?.user) {
    return <>{children}</>
  }

  // Check if we're on the main dashboard page
  const isMainDashboard = pathname === '/dashboard'

  return (
    <div className="flex h-screen bg-gray-50 dashboard-layout">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        {!isMainDashboard && <Header session={session} />}
        <main className="flex-1 overflow-y-auto bg-gray-50">
          <div className={`container mx-auto px-6 ${isMainDashboard ? 'py-4' : 'py-8'}`}>
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}