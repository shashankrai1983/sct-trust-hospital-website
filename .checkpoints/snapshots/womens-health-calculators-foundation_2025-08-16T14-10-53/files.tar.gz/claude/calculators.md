# Women's Health Calculators - SCT Trust Hospital Implementation Guide

## Theme Integration - Forest Green + Cream Design

### Website Color Palette
- **Primary Forest Green:** `#606c38` (primary-green)
- **Secondary Forest Green:** `#228B22` (forest-green)
- **Accent Cream:** `#fefae0` (accent-cream, bg-offwhite)
- **Primary Beige:** `#dda15e` (primary-beige)
- **Text Brown:** `#283618` (text-brown)
- **Secondary Brown:** `#bc6c25` (secondary-brown)

### Design Elements
- **Glass Cards:** `bg-white bg-opacity-80 backdrop-blur-sm shadow-warm rounded-xl border border-accent-cream/20`
- **Tubelight Navigation:** Glowing forest green effects with warm shadows
- **Professional Medical Theme:** Clean, trustworthy design without cultural elements
- **Animation Library:** Anime.js v4 + HTML5 Canvas for smooth interactions

## Primary Pregnancy Calculators

| Calculator Name | Input Required | Formula/Calculation Method | Output | Professional Engagement Elements | Forest Green Theme Animations (Anime.js v4 + Canvas) |
|---|---|---|---|---|---|
| **Due Date Calculator** | Last Menstrual Period (LMP) Date | LMP + 280 days (40 weeks) | Expected delivery date, current pregnancy week | **Professional Focus**: "Calculate your expected delivery date with medical precision"<br>**Achievement**: Pregnancy milestone tracking with medical accuracy<br>**Educational**: Evidence-based pregnancy information sharing<br>**Trust Building**: Medical insights backed by Dr. Amita Shukla's expertise | **Entry**: Calendar transforms with forest green morphing animation<br>**Processing**: Circular progress with medical iconography (stethoscope, heart)<br>**Result**: Baby silhouette grows with gentle scale animation in cream background<br>**Celebration**: Forest green particles with warm glow effects<br>**Milestone**: Medical badge appears with glass card effect |
| **Pregnancy Week Calculator** | LMP Date OR Current Date + Known Week | Days since LMP ÷ 7 = Weeks | Current week, trimester, days remaining | **Medical Progression**: Visual pregnancy journey with clinical milestones<br>**Professional Tracking**: Personalized pregnancy diary with medical accuracy<br>**Education**: Weekly medical insights and health recommendations<br>**Support**: Progress sharing with healthcare provider integration | **Entry**: Timeline transforms with forest green gradient transitions<br>**Progress**: Baby silhouette grows with gentle scale animation on cream background<br>**Trimester**: Background shifts between cream and soft green gradients<br>**Week Counter**: Numbers flip with smooth animation using forest green accents<br>**Journey Map**: SVG path draws in forest green with glass card overlay |
| **Conception Date Calculator** | LMP Date OR Due Date | LMP + 14 days OR Due Date - 266 days | Estimated conception date range | **Medical Precision**: "Scientific conception date estimation"<br>**Achievement**: "Medical Accuracy" certification with healthcare provider<br>**Educational**: Medical timing information sharing<br>**Trust**: Connect to evidence-based medical calendar | **Entry**: Calendar transitions with glass morphing effects<br>**Calculation**: Medical heart icon with gentle pulsing in forest green<br>**Result**: Clean geometric patterns transform to display date in cream cards<br>**Certificate**: Medical certificate appears with glass card animation<br>**Professional**: Forest green particles with warm medical glow |
| **Weight Gain Calculator** | Pre-pregnancy weight, height, current weight, pregnancy week | BMI = weight(kg) ÷ height(m)²<br>Recommended gain based on BMI categories | Recommended total gain, current status | **Health Tracking**: "Healthy Pregnancy" progress levels with medical guidelines<br>**Professional**: Compare with medical standards and healthy ranges<br>**Medical Achievement**: Earn "Optimal Health" certifications<br>**Care**: Medical guidance system with professional advice from Dr. Amita Shukla | **Input**: Weight display animates with smooth transitions in forest green<br>**Progress**: Health meter fills with forest green to cream gradients<br>**Comparison**: Medical charts slide in with glass card effects<br>**Achievement**: Professional badge appears with warm glow animation<br>**Care**: Gentle notification with forest green accent and warm shadows |

## Ovulation & Fertility Calculators

| Calculator Name | Input Required | Formula/Calculation Method | Output | Professional Engagement Elements |
|---|---|---|---|---|
| **Ovulation Calculator** | Last period date, cycle length | Next ovulation = LMP + (cycle length - 14) | Fertile window, ovulation date | **Medical Empowerment**: "Fertility Health" journey with evidence-based tracking<br>**Precision**: "Fertile Window" countdown with medical accuracy<br>**Support**: Professional "Conception Planning" guidance in Lucknow<br>**Evidence**: Medical fertility insights based on healthcare research | **Entry**: Calendar transforms with forest green blooming animation<br>**Processing**: Medical fertility wheel rotates with glass card overlay<br>**Fertile Window**: Forest green glow effect with cream particle system<br>**Countdown**: Numbers decrease with smooth forest green fade animation<br>**Success**: Medical iconography appears with clean SVG transitions |
| **Fertile Window Calculator** | LMP date, cycle length | Fertile period: Ovulation ± 5 days | 6-day fertile window | **Medical Tracking**: Fertility cycle monitoring with healthcare precision<br>**Professional Achievement**: "Cycle Accuracy" medical certifications<br>**Healthcare**: Success insights sharing with medical community<br>**Evidence**: Connect fertile days with medical timing guidelines | **Entry**: Timeline transforms with forest green arc animation<br>**Window**: Highlight zone expands with warm cream glow effect<br>**Tracking**: Medical connections appear with clean path drawing<br>**Achievement**: Professional badge rotates with glass card effect<br>**Medical**: Health indicators pulse with forest green accent |
| **Next Period Calculator** | Last period date, average cycle length | Next period = LMP + cycle length | Next period date, cycle tracking | **Health Management**: Smart medical reminders for cycle preparation<br>**Medical Tracking**: "Cycle Health" levels for consistent monitoring<br>**Education**: Period health education and wellness guidance<br>**Professional**: Health preparation tips sharing with healthcare providers | **Entry**: Calendar transitions with glass card perspective effects<br>**Cycle**: Circular progress with forest green to cream gradients<br>**Reminder**: Medical bell icon with gentle forest green pulse<br>**Tracking**: Health dots connect with smooth drawing animation<br>**Education**: Medical info cards slide up with warm shadow effects |

## Health Assessment Calculators

| Calculator Name | Input Required | Formula/Calculation Method | Output | Professional Engagement Elements |
|---|---|---|---|---|
| **BMI Calculator** | Height, Weight | BMI = Weight(kg) ÷ Height(m)² | BMI value, category, health implications | **Health Journey**: "Healthy Woman" medical wellness levels<br>**Medical Achievement**: Health improvement certifications with clinical accuracy<br>**Professional**: Compare with medical standards for women in Lucknow<br>**Healthcare**: Personalized medical recommendations from Dr. Amita Shukla | **Input**: Body silhouette animates with forest green transitions<br>**Calculation**: Health meter fills with forest green to cream gradients<br>**Category**: Medical labels slide in with glass card effects<br>**Comparison**: Professional charts appear with smooth stagger animation<br>**Recommendations**: Medical cards flip with warm shadow transitions |
| **High-Risk Pregnancy Assessment** | Age, medical history, lifestyle factors | Points-based scoring system | Risk level, recommendations | **Medical Care**: "Protecting maternal health" with professional responsibility<br>**Healthcare**: Proactive health monitoring achievements<br>**Professional**: Risk management success with Dr. Amita Shukla's medical guidance<br>**Medical Support**: Early warning system with professional healthcare messages | **Assessment**: Progress bar fills with forest green gradient transitions<br>**Risk Level**: Medical shield morphs with glass card effect<br>**Warning**: Gentle pulse with warm forest green transitions<br>**Achievement**: Medical trophy rises with professional scale animation<br>**Support**: Heart icon beats with caring cream and green rhythm |
| **Baby Birth Weight Predictor** | Mother's height, weight, father's height, pregnancy week | Statistical modeling based on parental factors | Estimated birth weight range | **Medical Prediction**: "Baby's health estimation" with evidence-based comparisons<br>**Healthcare**: "Healthy Development Planner" medical certificates<br>**Professional**: Compare predictions with medical standards and healthcare data<br>**Education**: Medical facts about birth weight and healthy development | **Prediction**: Baby silhouette grows with forest green weight animation<br>**Medical Chart**: Parent data morphs into baby health outline<br>**Certificate**: Medical scroll animates with clean path drawing<br>**Comparison**: Health charts slide into position with glass effects<br>**Facts**: Medical tooltip bubbles appear with warm shadow animation |

## Nutritional & Wellness Calculators

| Calculator Name | Input Required | Formula/Calculation Method | Output | Professional Engagement Elements |
|---|---|---|---|---|
| **Prenatal Vitamin Calculator** | Pregnancy week, breastfeeding status, dietary restrictions | RDA recommendations by trimester | Daily vitamin/mineral requirements | **Medical Nutrition**: "Prenatal Health" progression with medical vitamin knowledge<br>**Healthcare**: "Complete Nutrition" tracking with medical accuracy<br>**Professional**: Unlock evidence-based nutritional alternatives<br>**Education**: Healthy recipe sharing with medical guidance for pregnant women | **Vitamins**: Pills animate with forest green transitions into medical bottles<br>**Nutrition Meter**: Multi-colored bars fill with forest green to cream gradients<br>**Health Progress**: Medical silhouette morphs with professional achievement levels<br>**Nutrition**: Medical foods appear with glass card transitions<br>**Recipe Cards**: Flip animation with warm shadow and ingredient reveals |
| **Calorie Needs Calculator** | Age, weight, height, activity level, pregnancy/breastfeeding status | Harris-Benedict equation + pregnancy factor | Daily calorie requirements | **Medical Energy**: "Nutrition Expert" levels with evidence-based food knowledge<br>**Healthcare**: Daily calorie goal achievements with medical precision<br>**Professional**: Healthy meal plan sharing with medical community guidance<br>**Medical Care**: Custom diet plans with local Lucknow foods approved by Dr. Amita Shukla | **Energy Meter**: Forest green flame grows with calorie visualization<br>**Food Groups**: Healthy meal elements appear with glass card rotation<br>**Expert Levels**: Medical badges slide up with forest green glow<br>**Meal Plans**: Cards carousel with warm shadow transitions<br>**Local Foods**: Healthy Lucknow specialties appear with cream background |
| **Water Intake Calculator** | Weight, pregnancy/breastfeeding status, activity level | Base requirement + pregnancy factor | Daily water intake recommendation | **Health Hydration**: "Hydration Health" daily medical tracking<br>**Medical Achievement**: Water intake milestone celebrations with health benefits<br>**Healthcare**: Hydration monitoring with medical family guidance<br>**Medical Care**: Dehydration prevention with professional medical reminders | **Water Fill**: Animated wave effect with forest green to cream gradients<br>**Hydration Meter**: Forest green gradient flows upward in glass container<br>**Health Badge**: Water drop icon bounces with medical personality<br>**Tracking**: Connected droplets form with clean path animation<br>**Reminders**: Gentle medical notification with warm ripple effects |

## Clinical Assessment Tools

| Calculator Name | Input Required | Formula/Calculation Method | Output | Professional Engagement Elements |
|---|---|---|---|---|
| **Labor Probability Calculator** | Pregnancy week, symptoms checklist, cervical changes | Weighted scoring based on clinical indicators | Probability percentage, recommendations | **Medical Readiness**: "Labor preparation" medical assessment with professional guidance<br>**Healthcare**: "Birth Preparation Expert" medical achievements<br>**Professional**: Connect with other expecting mothers at SCT Trust Hospital<br>**Medical Care**: Early preparation to ensure optimal labor readiness | **Probability**: Circular progress with medical heartbeat rhythm in forest green<br>**Symptoms**: Medical checklist items check with gentle glass card pop<br>**Assessment**: Medical indicators morph into percentage with cream background<br>**Expert**: Medical badge appears with professional animation<br>**Preparation**: Medical timeline connects with warm forest green glow |
| **APGAR Score Calculator** | 5 clinical observations (heart rate, breathing, etc.) | Sum of scores (0-2 each category) | Total score, interpretation | **Medical Report**: "Baby's first health assessment" professional celebration<br>**Healthcare**: "Optimal Health Score" celebrations with medical family sharing<br>**Medical Education**: Unlock newborn care medical knowledge levels<br>**Professional**: Healthy baby achievements sharing with Dr. Amita Shukla's medical community | **Score Counter**: Numbers flip with medical precision in forest green<br>**Health Categories**: Medical icons fill with forest green to cream gradients<br>**Perfect Score**: Forest green particles burst with warm medical celebration<br>**Report Card**: Official medical document slides with glass card effect<br>**Knowledge**: Medical insights illuminate with educational forest green content |
| **Bishop Score Calculator** | Cervical dilation, effacement, station, consistency, position | Clinical scoring system | Score, labor readiness assessment | **Medical Expertise**: "Labor Readiness Professional" clinical knowledge<br>**Healthcare**: Understanding medical terminology with professional achievements<br>**Medical Control**: Taking informed control of birth preparation<br>**Professional**: Medical knowledge sharing with other expecting mothers | **Clinical Interface**: Medical chart animates with forest green professional precision<br>**Score Building**: Points accumulate with gentle forest green increment animation<br>**Expert Badge**: Medical stethoscope morphs into achievement symbol with glass effect<br>**Medical Terms**: Definitions expand with warm accordion animation<br>**Readiness**: Medical indicator system with forest green to cream transitions |

## Postpartum Calculators

| Calculator Name | Input Required | Formula/Calculation Method | Output |
|---|---|---|---|
| **Breastfeeding Calorie Calculator** | Age, weight, height, activity level, breastfeeding frequency | Base calories + 300-500 for breastfeeding | Daily calorie needs | **Medical Nutrition**: "Nourishing Mother" medical energy tracking<br>**Healthcare**: Balanced nutrition for mother and baby with medical guidance<br>**Medical Achievement**: Sustained energy milestone achievements with health benefits<br>**Professional**: Breastfeeding support community with medical connections | **Energy Flow**: Animated connection between mother and baby icons in forest green<br>**Calorie Counter**: Numbers increase with medical precision and warm transitions<br>**Mother-Baby Bond**: Hearts float with forest green to cream gradient connections<br>**Energy Levels**: Medical battery meter fills with warm maternal glow<br>**Community**: Medical support circles expand with gentle glass ripple effects |
| **Postpartum Recovery Timeline** | Delivery type, complications, age | Evidence-based recovery milestones | Recovery timeline, milestone tracking | **Medical Recovery**: "Recovery Expert" medical journey stages<br>**Healthcare**: Taking medical control of healing process<br>**Medical Achievement**: Recovery milestone celebrations with health tracking<br>**Professional**: Recovery story sharing with new mothers and medical guidance | **Timeline**: Progress path draws with forest green healing transitions<br>**Milestones**: Medical achievement markers appear with gentle glass card celebration<br>**Recovery**: Body silhouette gradually strengthens with warm forest green glow<br>**Expert**: Medical strength meter fills with professional empowering animations<br>**Healing**: Soft forest green to cream glow effects with nurturing medical warmth |
| **Baby Growth Percentile** | Baby's age, weight, height, head circumference | WHO/CDC growth charts comparison | Percentile rankings, growth trends | **Medical Tracking**: "Growth Expert" professional parenting expertise<br>**Healthcare**: Healthy growth celebration moments with medical accuracy<br>**Medical Understanding**: Understanding child development patterns with professional guidance<br>**Professional**: Medical growth comparison with peer standards | **Growth Chart**: Medical line graphs draw progressively in forest green<br>**Percentiles**: Medical position markers slide into place with glass card effects<br>**Baby Silhouette**: Grows proportionally with warm forest green measurement transitions<br>**Trends**: Smooth medical curve animations showing progress with cream backgrounds<br>**Celebrations**: Professional animations for healthy growth ranges with warm glow |

## Implementation Strategy - Step by Step Development

### Phase 1: Setup & Foundation

#### 1.1 Feature Branch Creation
```bash
git checkout -b feature/womens-health-calculators
```

#### 1.2 Navigation Integration (Update navbar.tsx)
```typescript
// Add to navLinks array between Services and Blog
{
  title: 'Women\'s Health Calculator',
  href: '/calculators',
  icon: Calculator, // Import from lucide-react
  submenu: [
    { title: 'Due Date Calculator', href: '/calculators/due-date-calculator' },
    { title: 'Pregnancy Week Calculator', href: '/calculators/pregnancy-week-calculator' },
    { title: 'Ovulation Calculator', href: '/calculators/ovulation-calculator' },
    { title: 'BMI Calculator', href: '/calculators/bmi-calculator' },
    // ... more calculators grouped by category
  ]
}
```

#### 1.3 Directory Structure Creation
```
/app/calculators/
├── layout.tsx                    # Calculator section layout
├── page.tsx                      # Calculator landing page
├── components/
│   ├── CalculatorTemplate.tsx    # Base template
│   ├── ForestThemeInputs.tsx     # Themed input components
│   ├── ResultsDisplay.tsx        # Results with animations
│   └── MedicalDisclaimer.tsx     # Professional disclaimer
├── due-date-calculator/
│   └── page.tsx
├── pregnancy-week-calculator/
│   └── page.tsx
└── [calculator-slug]/
    └── page.tsx
```

### Phase 2: Theme Implementation

#### 2.1 CSS Class Inheritance
```css
/* Use existing website classes */
.calculator-card {
  @apply glass-card p-6 max-w-2xl mx-auto;
}

.calculator-input {
  @apply border-2 border-primary-green/20 focus:border-primary-green bg-accent-cream rounded-lg px-4 py-3;
}

.calculator-button {
  @apply btn-green shadow-warm hover:shadow-warm-lg;
}

.result-display {
  @apply bg-gradient-to-br from-primary-green/10 to-forest-green/5 border border-primary-green/20 rounded-xl p-6;
}
```

#### 2.2 Forest Green + Cream Color Variables
```typescript
const calculatorTheme = {
  primary: '#606c38',      // primary-green
  secondary: '#228B22',    // forest-green
  accent: '#fefae0',       // accent-cream
  highlight: '#dda15e',    // primary-beige
  text: '#283618',         // text-brown
  background: '#fefae0'    // bg-offwhite
};
```

### Phase 3: Animation Setup (Anime.js v4)

#### 3.1 Anime.js Installation & Configuration
```bash
npm install animejs @types/animejs
```

#### 3.2 Animation Component Architecture
```typescript
// components/calculators/animations/ForestAnimations.tsx
import anime from 'animejs';

export const animateEntry = (target: string) => {
  anime({
    targets: target,
    opacity: [0, 1],
    scale: [0.8, 1],
    duration: 800,
    easing: 'easeOutElastic(1, .8)',
    backgroundColor: ['#fefae0', '#606c38']
  });
};

export const animateResult = (target: string) => {
  anime({
    targets: target,
    translateY: [-20, 0],
    opacity: [0, 1],
    duration: 600,
    easing: 'easeOutQuad',
    boxShadow: ['0 0 0 rgba(96, 108, 56, 0)', '0 10px 30px rgba(96, 108, 56, 0.1)']
  });
};
```

#### 3.3 HTML5 Canvas Integration
```typescript
// components/calculators/canvas/PregnancyVisualizer.tsx
export const PregnancyCanvas = ({ week }: { week: number }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    // Draw baby silhouette with forest green gradients
    // Animate growth based on pregnancy week
  }, [week]);
  
  return (
    <canvas 
      ref={canvasRef}
      className="w-full h-64 bg-gradient-to-br from-accent-cream to-primary-green/5"
    />
  );
};
```

### Phase 4: First Calculator Implementation - Due Date Calculator

#### 4.1 Component Structure
```typescript
// app/calculators/due-date-calculator/page.tsx
export default function DueDateCalculator() {
  const [lmpDate, setLmpDate] = useState<Date | null>(null);
  const [result, setResult] = useState<CalculationResult | null>(null);
  
  const calculateDueDate = () => {
    if (!lmpDate) return;
    
    const dueDate = new Date(lmpDate);
    dueDate.setDate(dueDate.getDate() + 280); // 40 weeks
    
    // Trigger animations
    animateResult('.result-card');
    
    setResult({
      dueDate,
      currentWeek: getCurrentWeek(lmpDate),
      trimester: getTrimester(lmpDate)
    });
  };
  
  return (
    <div className="theme-forest min-h-screen bg-accent-cream py-16">
      <div className="container mx-auto px-4">
        <div className="calculator-card">
          <h1 className="text-3xl font-bold text-primary-green mb-6">
            Due Date Calculator
          </h1>
          
          <ForestDatePicker 
            value={lmpDate}
            onChange={setLmpDate}
            label="Last Menstrual Period Date"
          />
          
          <button 
            onClick={calculateDueDate}
            className="calculator-button w-full mt-6"
          >
            Calculate Due Date
          </button>
          
          {result && (
            <ResultDisplay 
              result={result}
              theme="forest"
              animation="gentle-grow"
            />
          )}
          
          <MedicalDisclaimer doctor="Dr. Amita Shukla" />
        </div>
      </div>
    </div>
  );
}
```

#### 4.2 Reusable Components
```typescript
// components/calculators/ForestDatePicker.tsx
export const ForestDatePicker = ({ value, onChange, label }: Props) => {
  return (
    <div className="space-y-2">
      <label className="text-text-brown font-medium">{label}</label>
      <input
        type="date"
        value={value ? format(value, 'yyyy-MM-dd') : ''}
        onChange={(e) => onChange(new Date(e.target.value))}
        className="calculator-input w-full"
      />
    </div>
  );
};
```

### Phase 5: Development Workflow

#### 5.1 One Calculator at a Time Development
1. **Start with Due Date Calculator** (most popular, simple logic)
2. **Perfect the design pattern** (animations, theme, UX)
3. **Create reusable components** (inputs, results, animations)
4. **Test thoroughly** (mobile, desktop, animations)
5. **Move to next calculator** using established patterns

#### 5.2 Quality Gates
- **Theme Consistency**: All elements use forest green + cream palette
- **Animation Smoothness**: Anime.js animations feel natural and professional
- **Mobile Responsiveness**: Touch-friendly on all devices
- **Medical Accuracy**: All calculations verified and documented
- **Performance**: Fast loading, smooth animations

### Phase 6: Technical Requirements

#### 6.1 Input Validation
```typescript
const validateLMPDate = (date: Date): ValidationResult => {
  const today = new Date();
  const maxDate = new Date();
  maxDate.setMonth(maxDate.getMonth() - 10); // 10 months ago max
  
  if (date > today) {
    return { isValid: false, error: 'Date cannot be in the future' };
  }
  
  if (date < maxDate) {
    return { isValid: false, error: 'Date too far in the past' };
  }
  
  return { isValid: true };
};
```

#### 6.2 SEO Integration
```typescript
// app/calculators/due-date-calculator/page.tsx
export const metadata: Metadata = {
  title: 'Due Date Calculator | Dr. Amita Shukla | SCT Trust Hospital Lucknow',
  description: 'Calculate your expected delivery date with Dr. Amita Shukla\'s professional due date calculator in Lucknow. Accurate pregnancy week tracking.',
  keywords: 'due date calculator, pregnancy calculator, Dr. Amita Shukla, Lucknow, SCT Trust Hospital'
};
```

#### 6.3 Medical Disclaimer Component
```typescript
export const MedicalDisclaimer = ({ doctor }: { doctor: string }) => {
  return (
    <div className="mt-8 p-4 bg-primary-green/5 border border-primary-green/20 rounded-lg">
      <p className="text-sm text-text-brown">
        <strong>Medical Disclaimer:</strong> These results are estimates for educational purposes only. 
        Please consult with {doctor} at SCT Trust Hospital for personalized medical advice and care.
      </p>
    </div>
  );
};
```

### Phase 7: Deployment & Testing

#### 7.1 Testing Checklist
- [ ] All animations work smoothly on mobile and desktop
- [ ] Forest green + cream theme consistently applied
- [ ] Medical calculations are accurate
- [ ] Forms validate properly
- [ ] SEO metadata is complete
- [ ] Navigation integration works properly
- [ ] Medical disclaimers are visible

#### 7.2 Performance Optimization
- Lazy load calculator components
- Optimize Anime.js animations for 60fps
- Compress canvas assets
- Implement proper caching for calculation results

This implementation strategy ensures consistent theme integration, professional medical accuracy, and smooth user experience across all calculator types.