const { chromium } = require('playwright');

async function testLogin() {
  console.log('🚀 Starting Playwright login test...');
  
  // Launch browser
  const browser = await chromium.launch({ 
    headless: false, // Show browser window
    slowMo: 1000     // Slow down actions for visibility
  });
  
  const context = await browser.newContext();
  const page = await context.newPage();
  
  try {
    console.log('📍 Step 1: Navigating directly to login page...');
    await page.goto('http://localhost:3000/dashboard/login');
    
    // Take screenshot of login page
    await page.screenshot({ path: 'test-results/direct-login.png' });
    console.log('📸 Screenshot saved: direct-login.png');
    
    console.log('📍 Step 2: Checking if we are on login page...');
    console.log('✅ Accessing login page directly');
    
    console.log('📍 Step 3: Checking login page elements...');
    
    // Check if login form is present
    const emailInput = await page.locator('input[name="email"]');
    const passwordInput = await page.locator('input[name="password"]');
    const submitButton = await page.locator('button[type="submit"]');
    
    await page.waitForSelector('input[name="email"]', { timeout: 5000 });
    console.log('✅ Email input found');
    
    await page.waitForSelector('input[name="password"]', { timeout: 5000 });
    console.log('✅ Password input found');
    
    await page.waitForSelector('button[type="submit"]', { timeout: 5000 });
    console.log('✅ Submit button found');
    
    // Take screenshot of login page
    await page.screenshot({ path: 'test-results/login-page.png' });
    console.log('📸 Screenshot saved: login-page.png');
    
    console.log('📍 Step 4: Filling login form...');
    
    // Fill login form
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@scttrusthospital.com';
    const adminPassword = 'admin123'; // Test password
    
    await emailInput.fill(adminEmail);
    console.log(`📧 Email filled: ${adminEmail}`);
    
    await passwordInput.fill(adminPassword);
    console.log('🔒 Password filled');
    
    // Take screenshot before submit
    await page.screenshot({ path: 'test-results/form-filled.png' });
    console.log('📸 Screenshot saved: form-filled.png');
    
    console.log('📍 Step 5: Submitting login form...');
    await submitButton.click();
    
    console.log('⏳ Waiting for authentication...');
    
    // Wait for either success redirect or error message
    try {
      // Wait for successful redirect to dashboard
      await page.waitForURL('**/dashboard**', { timeout: 10000 });
      console.log('✅ Login successful! Redirected to dashboard');
      
      // Take screenshot of dashboard
      await page.screenshot({ path: 'test-results/dashboard-success.png' });
      console.log('📸 Screenshot saved: dashboard-success.png');
      
      // Check for dashboard content
      const dashboardTitle = await page.locator('h1').textContent();
      console.log(`📊 Dashboard title: ${dashboardTitle}`);
      
    } catch (redirectError) {
      console.log('⚠️ Redirect failed, checking for error messages...');
      
      // Check for error messages
      const errorMessage = await page.locator('text="Invalid email or password"');
      if (await errorMessage.isVisible()) {
        console.log('❌ Login failed: Invalid credentials');
      } else {
        console.log('❓ Unknown error occurred');
      }
      
      // Take screenshot of error state
      await page.screenshot({ path: 'test-results/login-error.png' });
      console.log('📸 Screenshot saved: login-error.png');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    
    // Take screenshot of error state
    await page.screenshot({ path: 'test-results/test-error.png' });
    console.log('📸 Error screenshot saved: test-error.png');
  }
  
  console.log('📍 Step 6: Test cleanup...');
  await page.waitForTimeout(3000); // Wait 3 seconds to see result
  await browser.close();
  console.log('🏁 Test completed');
}

// Run the test
testLogin().catch(console.error);