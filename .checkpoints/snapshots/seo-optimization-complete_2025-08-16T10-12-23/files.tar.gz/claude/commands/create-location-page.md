# Create Location Page Command

---
description: "Create comprehensive location pages with advanced research, batch processing, SEO optimization, and production-ready quality controls"
argument-hint: "[location-name[,location2,...]] [--research-options] [--seo-options] [--quality-options] [--generation-control] [--output-options] [--performance-options]"
allowed-tools: 
  - "Read"
  - "Write" 
  - "WebFetch"
  - "Grep"
  - "Glob"
  - "Edit"
  - "MultiEdit"
  - "TodoWrite"
  - "WebSearch"
  - "Bash"
---

## Advanced Location Page Generation System

Generate comprehensive, SEO-optimized location pages with deep research, competitive analysis, and production-ready quality controls for gynecological services.

### Basic Command Structure:
```
/create-location-page [location-name] [options]
```

### Simple Examples:
```bash
# Basic location page generation
/create-location-page hazratganj

# With specific options
/create-location-page indira-nagar --priority=high

# With comprehensive research
/create-location-page rajajipuram --demographic-research=deep --competitive-focus
```

### Advanced Examples:
```bash
# Full optimization with quality gates
/create-location-page gomti-nagar --seo-optimize --qa-validate --quality-threshold=85

# Batch generation for multiple locations
/create-location-page hazratganj,indira-nagar,rajajipuram --batch --parallel

# Development mode with detailed reporting
/create-location-page alambagh --dry-run --verbose --save-reports

# Production-ready with all validations
/create-location-page aliganj --production --auto-optimize --certification=gold
```

## Available Options:

### Research & Content Options:
- `--demographic-research=basic|deep` - Level of demographic analysis
- `--competitive-focus` - Enhanced competitor analysis
- `--medical-focus=general|specialized` - Medical content specialization
- `--local-landmarks` - Include local landmark references

### SEO & Optimization:
- `--seo-optimize` - Run full SEO optimization pipeline
- `--keyword-focus="custom keyword"` - Override primary keyword
- `--local-seo` - Enhanced local SEO signals
- `--schema-rich` - Comprehensive schema markup

### Quality & Validation:
- `--qa-validate` - Run comprehensive QA testing
- `--quality-threshold=70|80|85|90` - Minimum quality score
- `--certification=bronze|silver|gold|platinum` - Target certification level
- `--medical-compliance` - Enhanced medical accuracy validation

### Generation Control:
- `--dry-run` - Preview without creating files
- `--overwrite` - Replace existing location pages
- `--backup` - Create backups before overwriting
- `--batch` - Process multiple locations
- `--parallel` - Parallel processing for batch operations

### Output & Reporting:
- `--verbose` - Detailed execution logging
- `--save-reports` - Generate comprehensive reports
- `--format=markdown|json|both` - Report format
- `--output-dir="./custom-output"` - Custom output directory

### Performance Options:
- `--priority=low|medium|high` - Processing priority
- `--max-iterations=3` - SEO optimization iterations
- `--timeout=300` - Operation timeout in seconds

## Real-World Usage Examples:

### 🎯 Production Location Page:
```bash
/create-location-page hazratganj \
  --demographic-research=deep \
  --competitive-focus \
  --seo-optimize \
  --qa-validate \
  --quality-threshold=85 \
  --certification=gold \
  --save-reports \
  --medical-compliance
```

### 🚀 Quick Development Test:
```bash
/create-location-page test-location \
  --dry-run \
  --verbose \
  --quality-threshold=70 \
  --format=markdown
```

### 📦 Batch Production Deployment:
```bash
/create-location-page hazratganj,indira-nagar,rajajipuram,aliganj,gomti-nagar \
  --batch \
  --parallel \
  --seo-optimize \
  --qa-validate \
  --quality-threshold=80 \
  --backup \
  --save-reports \
  --production
```

## Command Workflow:

When you run the command, here's what happens:

1. 🔍 **Research Phase** - Gathers factual location data via web search
2. 📝 **Content Generation** - Creates location-specific content with brand voice
3. 🚀 **SEO Optimization** - Runs iterative SEO improvements (if enabled)
4. 🧪 **Quality Assurance** - Comprehensive testing and validation (if enabled)
5. 📁 **File Generation** - Creates TypeScript location data and Next.js pages
6. 📊 **Reporting** - Generates detailed quality and performance reports

## Expected Output:

```
🎯 Starting location page generation for Hazratganj
🔍 Research Phase: Gathering location data... ✅ (2.3s)
📝 Content Generation: Creating location-specific content... ✅ (1.8s)
🚀 SEO Optimization: Running 3 optimization iterations... ✅ (4.2s)
🧪 Quality Assurance: 26 tests across 5 categories... ✅ (1.9s)
📁 File Generation: Creating 3 files... ✅ (0.8s)
📊 Reports: Saving QA and SEO reports... ✅ (0.3s)

✅ Location page completed for Hazratganj
📊 Overall Quality Score: 87/100 (Gold Certification)
📄 Reports saved to: ./reports/hazratganj-2024-01-15/
🌐 Page URL: /gynecologist-in-hazratganj
⏱️  Total Time: 11.3s
```

## Execution Workflow:

I will execute the comprehensive location page generation workflow for: **$ARGUMENTS**

### Phase 1: Argument Parsing & Setup
1. **Parse Arguments**: Extract location(s) and options from $ARGUMENTS
2. **Validate Options**: Check for conflicting flags and requirements
3. **Setup Environment**: Initialize directories, backup systems, and reporting
4. **Batch Detection**: Identify single vs. multiple location processing

### Phase 2: Research & Analysis (Per Location)
1. **Geographic Research**: Coordinates, landmarks, transportation routes, distance calculations from SCT Trust Hospital
2. **Demographic Analysis**: Population data, economic profiles, age demographics, professional composition using web research
3. **Competitive Healthcare Analysis**: Identify competing gynecologists, hospitals, pricing, services, patient reviews
4. **Health Market Research**: Common health concerns, insurance providers, medical service gaps in the area

### Phase 3: Content Generation (Per Location)
1. **Location Data Creation**: Generate TypeScript data file following the established schema from `gomti-nagar.ts`
2. **SEO Content Optimization**: Local keyword research, meta descriptions, schema markup
3. **Medical Content Validation**: Fact-checking, medical disclaimer compliance, professional tone
4. **Brand Consistency**: Align with Dr. Amita Shukla's practice voice and messaging

### Phase 4: SEO Optimization (If Enabled)
1. **Keyword Analysis**: Research local search terms and competition
2. **Iterative Optimization**: Run multiple optimization cycles based on --max-iterations
3. **Local SEO Signals**: Implement location-specific SEO enhancements
4. **Schema Markup**: Rich snippets and structured data implementation

### Phase 5: Quality Assurance (If Enabled)
1. **Content Quality Scoring**: Grammar, uniqueness, readability analysis
2. **Technical Validation**: TypeScript compilation, Next.js build verification
3. **Medical Compliance**: Medical accuracy verification, disclaimer presence
4. **SEO Optimization**: Local search optimization scoring
5. **Performance Optimization**: Page speed and accessibility checks
6. **Certification Scoring**: Bronze/Silver/Gold/Platinum quality assessment

### Phase 6: File Generation & Implementation
1. **Dry-Run Preview**: Show what would be created (if --dry-run enabled)
2. **Backup System**: Create backups of existing files (if --backup enabled)
3. **File Creation**: Generate location data file at `data/locations/[location-name].ts`
4. **Route Creation**: Generate Next.js page at `app/gynecologist-in-[location]/page.tsx`
5. **Template Integration**: Use existing `LocationPageTemplate.tsx` component
6. **Asset Management**: Optimize and place associated media files

### Phase 7: Reporting & Documentation
1. **Research Summary**: Demographic and competitive analysis findings
2. **Quality Metrics**: Content quality scores and technical validation results
3. **SEO Performance**: Keyword optimization and local search potential
4. **Medical Compliance Report**: Safety and accuracy verification
5. **Implementation Guide**: Files created and integration instructions
6. **Batch Summary**: Overall results for multiple location processing

## Expected Output Files:
- `data/locations/[location-name].ts` - Comprehensive location data
- `app/gynecologist-in-[location]/page.tsx` - Optimized location page
- `reports/[location-name]-research-report.md` - Research findings (if --save-reports)
- `reports/[location-name]-qa-report.md` - Quality assurance results (if --save-reports)
- `backups/[location-name]-backup-[timestamp]/` - Backup files (if --backup enabled)

## Quality Standards & Certification Levels:

### Bronze Certification (70-79/100):
- **Content Uniqueness**: >90% unique content
- **SEO Score**: >70/100 technical SEO
- **Medical Accuracy**: Basic fact-checking
- **Performance**: Lighthouse >80

### Silver Certification (80-84/100):
- **Content Uniqueness**: >93% unique content
- **SEO Score**: >75/100 technical SEO
- **Medical Accuracy**: Enhanced medical validation
- **Performance**: Lighthouse >85
- **Accessibility**: WCAG 2.1 A compliance

### Gold Certification (85-89/100):
- **Content Uniqueness**: >95% unique content
- **SEO Score**: >80/100 technical SEO
- **Medical Accuracy**: Comprehensive medical verification
- **Performance**: Lighthouse >90
- **Accessibility**: WCAG 2.1 AA compliance

### Platinum Certification (90-100/100):
- **Content Uniqueness**: >98% unique content
- **SEO Score**: >85/100 technical SEO
- **Medical Accuracy**: Expert-level medical validation
- **Performance**: Lighthouse >95
- **Accessibility**: WCAG 2.1 AAA compliance
- **Advanced Features**: Rich snippets, voice search optimization

## Batch Processing Logic:

When processing multiple locations (comma-separated), the system will:

1. **Parse Locations**: Split comma-separated location names
2. **Validate All Locations**: Check each location for feasibility
3. **Sequential Processing**: Process each location individually (default)
4. **Parallel Processing**: Process multiple locations simultaneously (if --parallel enabled)
5. **Progress Tracking**: Show progress across all locations
6. **Error Handling**: Continue processing remaining locations if one fails
7. **Batch Reporting**: Generate summary report for all processed locations

### Batch Example Output:
```
🎯 Starting batch location page generation for 3 locations
📍 Processing: hazratganj, indira-nagar, rajajipuram

Location 1/3: Hazratganj
🔍 Research Phase: ✅ (2.1s) | 📝 Content: ✅ (1.5s) | 🧪 QA: ✅ (1.8s)
📊 Quality Score: 87/100 (Gold) | ⏱️ Time: 8.2s

Location 2/3: Indira Nagar  
🔍 Research Phase: ✅ (2.3s) | 📝 Content: ✅ (1.7s) | 🧪 QA: ✅ (1.9s)
📊 Quality Score: 91/100 (Platinum) | ⏱️ Time: 9.1s

Location 3/3: Rajajipuram
🔍 Research Phase: ✅ (2.0s) | 📝 Content: ✅ (1.4s) | 🧪 QA: ✅ (1.7s)
📊 Quality Score: 84/100 (Silver) | ⏱️ Time: 7.8s

✅ Batch processing completed!
📊 Average Quality Score: 87.3/100
📄 Reports saved to: ./reports/batch-2024-01-15/
⏱️ Total Time: 25.1s (3 locations)
🎯 Success Rate: 100% (3/3 locations)
```

---

## Starting Execution

**🎯 Starting location page generation for: $ARGUMENTS**

Let me begin by parsing the arguments, validating options, and executing the comprehensive research and generation workflow with progress tracking, quality scoring, and detailed reporting...