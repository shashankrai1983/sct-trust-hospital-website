import NextAuth, { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import bcrypt from 'bcryptjs'

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { 
          label: 'Email', 
          type: 'email',
          placeholder: 'admin@scttrusthospital.com' 
        },
        password: { 
          label: 'Password', 
          type: 'password' 
        }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        // Hardcoded admin user - no database lookup needed
        const adminEmail = process.env.ADMIN_EMAIL
        const adminPasswordHash = process.env.ADMIN_PASSWORD_HASH

        if (!adminEmail || !adminPasswordHash) {
          console.error('Admin credentials not configured in environment variables')
          return null
        }

        // Check if email matches
        if (credentials.email !== adminEmail) {
          return null
        }

        // Verify password
        try {
          const isValidPassword = await bcrypt.compare(credentials.password, adminPasswordHash)
          
          if (isValidPassword) {
            return {
              id: 'admin',
              email: adminEmail,
              name: 'Admin User',
              role: 'admin'
            }
          }
        } catch (error) {
          console.error('Password verification error:', error)
        }

        return null
      }
    })
  ],
  session: {
    strategy: 'jwt'
  },
  callbacks: {
    async jwt({ token, user }) {
      // Persist the role to the token right after signin
      if (user) {
        token.role = user.role
      }
      return token
    },
    async session({ session, token }) {
      // Send properties to the client
      if (token.role) {
        session.user.role = token.role
      }
      return session
    }
  },
  pages: {
    signIn: '/dashboard/login',
    error: '/dashboard/login' // Redirect errors to login page
  },
  secret: process.env.NEXTAUTH_SECRET
}

export default NextAuth(authOptions)