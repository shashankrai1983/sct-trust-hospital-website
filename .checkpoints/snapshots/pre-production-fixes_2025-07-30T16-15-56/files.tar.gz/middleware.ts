import { withAuth } from 'next-auth/middleware'
import { NextResponse } from 'next/server'

export default withAuth(
  function middleware(req) {
    const { pathname } = req.nextUrl
    
    // Allow access to login page without authentication
    if (pathname === '/dashboard/login') {
      return NextResponse.next()
    }
    
    // For other dashboard routes, authentication is required
    // The withAuth wrapper will handle the redirect to login
    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const { pathname } = req.nextUrl
        
        // Always allow access to login page
        if (pathname === '/dashboard/login') {
          return true
        }
        
        // Require valid token for other dashboard routes
        return !!token
      },
    },
    pages: {
      signIn: '/dashboard/login',
    },
  }
)

// Only protect authenticated dashboard routes
export const config = {
  matcher: [
    '/dashboard',
    '/dashboard/appointments/:path*'
  ]
}