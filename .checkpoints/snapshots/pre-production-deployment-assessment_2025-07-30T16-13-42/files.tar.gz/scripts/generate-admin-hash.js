const bcrypt = require('bcryptjs');

// Generate hash for admin password
async function generateHash() {
  const password = 'admin123'; // Change this to your desired admin password
  const saltRounds = 12;
  
  try {
    const hash = await bcrypt.hash(password, saltRounds);
    console.log('Admin Password Hash:');
    console.log(hash);
    console.log('\nAdd this to your .env file:');
    console.log(`ADMIN_PASSWORD_HASH=${hash}`);
  } catch (error) {
    console.error('Error generating hash:', error);
  }
}

generateHash();