# Page snapshot

```yaml
- text: "{\"error\":\"Invalid credentials\"}"
```