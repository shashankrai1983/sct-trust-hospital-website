import { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../auth/[...nextauth]'
import { MongoClient } from 'mongodb'

const uri = process.env.MONGODB_URI!
const client = new MongoClient(uri)

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Check authentication
  const session = await getServerSession(req, res, authOptions)
  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    await client.connect()
    const db = client.db(process.env.MONGODB_DB)
    const collection = db.collection('appointments')

    // Get current date ranges
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const startOfWeek = new Date(today)
    startOfWeek.setDate(today.getDate() - today.getDay())
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)

    // Get statistics
    const [
      totalAppointments,
      todayAppointments,
      thisWeekAppointments,
      thisMonthAppointments,
      recentAppointments
    ] = await Promise.all([
      // Total appointments
      collection.countDocuments(),
      
      // Today's appointments
      collection.countDocuments({
        createdAt: { $gte: today }
      }),
      
      // This week's appointments
      collection.countDocuments({
        createdAt: { $gte: startOfWeek }
      }),
      
      // This month's appointments
      collection.countDocuments({
        createdAt: { $gte: startOfMonth }
      }),
      
      // Recent appointments (last 10)
      collection.find({})
        .sort({ createdAt: -1 })
        .limit(10)
        .toArray()
    ])

    const stats = {
      totalAppointments,
      todayAppointments,
      thisWeekAppointments,
      thisMonthAppointments
    }

    res.status(200).json({
      stats,
      recentAppointments
    })

  } catch (error) {
    console.error('Dashboard stats error:', error)
    res.status(500).json({ error: 'Internal server error' })
  } finally {
    await client.close()
  }
}